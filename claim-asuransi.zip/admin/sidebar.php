<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
	<ul class="nav menu">
		<li><a href="index.php"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Dashboard</a></li>
		<li><a href="asuransi.php"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Asuransi</a></li>
		<li><a href="status_pengerjaan.php"><svg class="glyph stroked pencil"><use xlink:href="#stroked-pencil"></use></svg> Status Pengerjaan</a></li>
		<li><a href="claim.php"><svg class="glyph stroked table"><use xlink:href="#stroked-table"></use></svg> Data Claim</a></li>
		<li><a href="laporan.php"><svg class="glyph stroked line-graph"><use xlink:href="#stroked-line-graph"></use></svg> Laporan</a></li>		
	</ul>
</div><!--/.sidebar-->