<header> 
  <div class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.php"><img src="assets/img/basic/logo.png" alt="" width="124" height="50" /></a>
      </div>
      <div class="nav-links">
        <ul class="nav navbar-nav">
          <li class="dropdown"><a href="index.php">Home </a></li>
           <li class="dropdown"><a href="#" >Our Company<i class="icon-caret-down"></i></a>
         		<ul class="dropdown-menu">
           	  <li><a href="visi-misi.php">Visi, Misi & Moto</a></li>
              <li><a href="lokasi.php">Lokasi</a></li>
            </ul>
           </li>
           <li class="dropdown"><a href="list-insurance.php" >List Insurance Company</a>
           </li>
        </ul>
      </div><!--/.nav-collapse -->
    </div>
  </div>
</header>  