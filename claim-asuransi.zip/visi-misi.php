<?php include 'head.php'; ?>
<body>
<!--=========================================
				Navigation
  =========================================-->   
<?php include 'menu.php';?>


<div class="promotion container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-9">
            <h4>Visi</h4>
            <p align="justify">
            Menjadi bengkel kendaraan bermotor yang termodern & terlengkap untuk segala jenis kendaraan bermotor.
            </p>
            <h4>Misi</h4>
            <p align="justify">
            Kami percaya bahwa tanggung jawab yang paling utama adalah terhadap pelanggan dengan memberikan pelayanan yang ramah serta hasil kerja yang memuaskan terhadap segala jenis kendaraan yang kami kerjakan.
            </p>
            <h4>Moto</h4>
            <p align="justify">
            "Kepuasan pelanggan adalah lambang keberhasilan kami"
            </p>
        </div>
    </div>
</div>

<!--=================================
Clients
=================================-->
 <div class="clearfix"></div>
<section id="clients-container">
        <div class="container">
        
          <h3>Insurance</h3> 
          <div class="clients">
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/1.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/2.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/3.jpeg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/4.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/5.jpg" alt="" />
                 </a>
          
          </div>
          <div class="clearfix"></div>
     </div>
</section>
 <div class="clearfix"></div>
<!--=========================================================
    #
    #							Footer
    #==========================================================-->
<?php include 'footer.php' ;?>