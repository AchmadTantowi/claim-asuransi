<?php include 'head.php'; ?>
<body>
<!--=========================================
				Navigation
  =========================================-->   
<?php include 'menu.php';?>


<div class="promotion container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-9">
            
            <p align="justify">
            <center>
            <h4>DAFTAR REKANAN ASURANSI </h4>
            <table border="1">
                <tr>
                    <td>1.</td>
                    <td><img src="assets/img/clients/1.jpg" alt="" /></td>
                    <td>P.T Asuransi Bina Dana Arta</td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td><img src="assets/img/clients/2.jpg" alt="" /></td>
                    <td>PT. Kurnia Insurance Indonesia</td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td><img src="assets/img/clients/3.jpeg" alt="" /></td>
                    <td>P.T.Asuransi Allianz Utama Indonesia</td>
                </tr>
                <tr>
                    <td>4.</td>
                    <td><img src="assets/img/clients/4.jpg" alt="" /></td>
                    <td>MNC Insurance</td>
                </tr>
                <tr>
                    <td>5.</td>
                    <td><img src="assets/img/clients/5.jpg" alt="" /></td>
                    <td>PT. Asuransi Reliance Indonesia</td>
                </tr>
                <tr>
                    <td>6.</td>
                    <td><img src="assets/img/clients/6.jpg" alt="" /></td>
                    <td>Zurich</td>
                </tr>
                <tr>
                    <td>8.</td>
                    <td><img src="assets/img/clients/8.jpg" alt="" /></td>
                    <td>Bosowa Periskop</td>
                </tr>
                <tr>
                    <td>9.</td>
                    <td><img src="assets/img/clients/9.jpg" alt="" /></td>
                    <td>PT. Assuransi Buana Independent ( Khusus Company )</td>
                </tr>
                <tr>
                    <td>10.</td>
                    <td><img src="assets/img/clients/10.jpg" alt="" /></td>
                    <td>PT. Batavia Malacca Wuwungan</td>
                </tr>
                <tr>
                    <td>11.</td>
                    <td><img src="assets/img/clients/11.jpg" alt="" /></td>
                    <td>PT. Central Sejahtera Insurance</td>
                </tr><tr>
                    <td>12.</td>
                    <td><img src="assets/img/clients/12.jpg" alt="" /></td>
                    <td>PT. Asuransi Staco Mandiri</td>
                </tr>
                <tr>
                    <td>13.</td>
                    <td><img src="assets/img/clients/13.jpg" alt="" /></td>
                    <td>PT. Tugu Pratama Indonesia</td>
                </tr>
                <tr>
                    <td>14.</td>
                    <td><img src="assets/img/clients/14.jpg" alt="" /></td>
                    <td>PT. Asuransi Rama Satria Wibawa</td>
                </tr>
            </table>
            </center>
            </p>
        </div>
    </div>
</div>


 <div class="clearfix"></div>
<!--=========================================================
    #
    #							Footer
    #==========================================================-->
<?php include 'footer.php' ;?>