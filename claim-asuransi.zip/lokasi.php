<?php include 'head.php'; ?>
<body>
<!--=========================================
				Navigation
  =========================================-->   
<?php include 'menu.php';?>


<div class="promotion container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-9">
            <h4>LAYANAN PRIMA 1 ( Kantor Pusat )</h4>
            <p align="justify">
             
Jl. Jelambar Barat III No. 12-A<br>
Jakarta Barat 11460<br>
Tlp. : 021-5665930,5665931 Fax.5646485<br>
E-mail : LPM1@layananprima.com<br>
Up : Bp. Iwan, Bp. Rochman, & Ibu Santi<br>
 
Posisi bengkel terletak di perbatasan antara wilayah Jakarta Barat (Jl.Pangeran Tubagus Angke Raya) dengan wilayah Jakarta Utara (Jembatan Dua-Pluit ).<br>
 
Bila melalui Tol Cawang - Bandara Soekarno-Hatta, keluar melalui pintu Tol Jembatan - Tubagus Angke, dan menempuh jalan sekitar 500 meter dari pintu Tol tersebut
            </p>
            <h4>LAYANAN PRIMA 2</h4>
            <p align="justify">
            Jl. H. Muchtar Raya No. 2<br>
Ciledug – Kodya Tangerang <br>
Tlp : 021-7341960,<br>
Fax : 021-7341821<br>
E-mail : layprima2@yahoo.com <br>
Up : Bp. Budi Santoso, Bp. Humaedi, Bp. Panca<br>
 
Posisi bengkel terletak di perbatasan antara wilayah Jakarta Selatan dengan Kodya Tangerang, diantara Universitas Budi Luhur dan Giant Kreo di Jalan Ciledug Raya.
            </p>
            <h4>LAYANAN PRIMA 3</h4>
            <p align="justify">
            Jl. Sultan Agung Tirtayasa no. 7<br>
Kunciran Indah- Alam Sutra Tangerang <br>
Tlp : 021 - 73446796<br>
Fax : 021 - 73446797<br>
E-mail : layprima3@yahoo.com<br>
Up : Bp. Rohman dan Bp. Roni
            </p>
        </div>
    </div>
</div>

<!--=================================
Clients
=================================-->
 <div class="clearfix"></div>
<section id="clients-container">
        <div class="container">
        
          <h3>Insurance</h3> 
          <div class="clients">
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/1.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/2.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/3.jpeg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/4.jpg" alt="" />
                 </a>
                 
                 <a href="#" class="client">
                 	<img src="assets/img/clients/5.jpg" alt="" />
                 </a>
          
          </div>
          <div class="clearfix"></div>
     </div>
</section>
 <div class="clearfix"></div>
<!--=========================================================
    #
    #							Footer
    #==========================================================-->
<?php include 'footer.php' ;?>