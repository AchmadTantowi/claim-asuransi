<footer class="modal-footer">
    <ul class="container copyrights row-fluid">    
    	<li>
        	<span class="detail">&copy; 2016 Layanan Prima. All rights reserved</span>
        </li>
    </ul> 
</footer><!--footer ends-->

<script src="assets/js/jquery-1.10.1.min.js"></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/jquery.flexslider-min.js"></script>
<script src="assets/js/isotope.js"></script>
<script src="assets/js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>

<script src="assets/js/tweetable.jquery.min.js"></script>
<script src="assets/js/jquery.mobilemenu.js" type="text/javascript"></script>
<script src="assets/js/jquery.prettyPhoto.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>